
from django.contrib import admin
from django.urls import path
# from django.conf.urls import url
# from myapp import views

# urlpatterns = [

#     path('admin/', admin.site.urls),
#     url("book/",views.BookAPIView.as_view()), #new

# ]



from django.conf.urls import url

from myapp import views

from rest_framework import routers

from django.urls import include

router = routers.DefaultRouter()

router.register('book',views.BookViewSet)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include(router.urls))

]